<div align="center">
<img width="120px"  src="https://raw.githubusercontent.com/no-te-rindas/logo/main/Logo/LeonidasEsteban-destello-envolvente-cuadrada.png" />
</div>

# Calendario
Aprovecha tu tiempo al máximo y planifica tus actividades en este increíble calendario que tenemos para ti.

## Requerimientos
- Exporta estilos con el siguiente plugin: https://www.figma.com/community/plugin/972939585144317012/Figma-to-CSS
- Accesibilidad como prioridad
- Sube tu código a GitHub
- Publica tu resultado con github pages
- Mándalo a revisión desde tu [perfil](https://leonidasesteban.com/estudiante)

Lleva el diseño al código utilizando tu framework favorito, o con HTML y CSS, no hay ninguna limitación.


## Desktop

<img width="400px"  src="https://raw.githubusercontent.com/uxcristopher/imagenes/main/Readmes/calendario/calendario-desktop.png" />


## Disclaimer

Todas son propuestas, el propósito de **/Proyectos** es brindarte el diseño, el límite de la creación lo dictan tus ganas de hacerlo realidad y tu skills del momento a la hora de codear.


## Créditos

Encuentra más proyectos asombrosos en [/Proyectos](https://leonidasesteban.com/proyectos)

Diseñado con ♥️ en leonidasesteban.com
